export const handleLegendToggle = (value) => ({
  type: 'HANDLE_LEGEND_TOGGLE',
  payload: value,
});
